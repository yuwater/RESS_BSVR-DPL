function model= SVRTrain1(X,Y,Hyperparameters)   
 %Training Bayesian epsilon-SVR model 
 [m n] = size(X);  % number of design sites and their dimension
 
 MInput = mean(X);   SInput= std(X); %Normalization of data
 X= (X-repmat( MInput,m,1)) ./ repmat(SInput,m,1);
 Moutput=mean(Y); Soutput=std(Y);
 Y=(Y-repmat(Moutput,m,1))./repmat(Soutput,m,1);
 
  Hyperparameters=exp(Hyperparameters); %Hyper-parameters
  C=Hyperparameters(1);                 %Trade-off parameter
  e=Hyperparameters(2);                 %Hyper-parameter epsilon
  theta=Hyperparameters(3:end);         %Covariance function hyper-parameters
  
   H=SVRcorrgauss1(theta, X);            %Upper triangular Covariance matrix
   H1=full(H);  H=H1+H1'-diag(ones(1,m));
   
   H=H+diag(1./C.*ones(m,1));      %Regularized Covariance matrix
   Hb =[H -H; -H H];

   f= [(e.*ones(m,1) - Y); (e.*ones(m,1) + Y)];  
     
     x0 = ones(2*m,1);        % The starting point
     lb = zeros(2*m,1);       % Set the bounds: alphas >= 0
     options=optimoptions('quadprog', 'Algorithm','interior-point-convex','Display','off','StepTolerance',10^(-15));
     alpha=quadprog(Hb,f,[],[],[],[],lb,[],x0,options); %quadratic programming
     beta= alpha(1:m) - alpha(m+1:2*m);
   
     svi=find(10^(-5)<abs(beta));  %Found support vector
     model.Input=X;
     model.Output=Y;
     model.parameter=beta;
     model.Kernel='Gaussian';
     model.C=C; 
     model.epsilon=e; 
     model.SV=svi; 
     model.Kernelmatrix=H;
     model.Inputmoment=[ MInput; SInput];
     model.outputmoment=[Moutput; Soutput];
     model.theta=theta;
end 
     
     
     
     
     
     
     