clear all;
LearningFunction=input('please input the learning function=');
format long
global DisType mu sigma
N0=12;%����ģ�ͳ�ʼ����
N_tianchong=10000;
N=10000000;
%%%%2D analytic example with two failure regions
DisType={'normal';'normal'};
n=2;
mu=[0 0];
sigma=[1 1];
c=3;
% c=4;
g=@(x)min([c-1-x(:,2)+exp(-x(:,1).^2./10)+(x(:,1)./5).^4,c.^2./2-x(:,1).*x(:,2)],[],2);
G=@(v)g(v);

Mu=zeros(1,n);
Sigma=ones(1,n);
rou=eye(n,n);
cov_matrix=diag(Sigma.*Sigma*rou);
for i=1:n
    MDataG(:,i)=lhsnorm(Mu(i),Sigma(i).^2,N,1); 
end
for i=1:n
    Data(:,i)=unifrnd(Mu(i)-5.*Sigma(i),Mu(i)+5.*Sigma(i),N0,1);
end
g0=G(Data);
for i=1:n
     Ah1(:,i)=unifrnd(Mu(i)-5.*Sigma(i),Mu(i)+5.*Sigma(i),N_tianchong,1);
end
Ah=MDataG;
for h=1:500
%%%Kriging����
tc1=n;
addpath(genpath('dace'));
X1=Data;
Y1=g0;
theta1=1.*ones(1,tc1);
lob1=1e-6.*ones(1,tc1);
upb1=200.*ones(1,tc1);
[dmodel1,perf1]=dacefit(X1,Y1,@regpoly0,@corrgauss,theta1,lob1,upb1);%%%%%%%%%%%%@regpoly0
GK=@(t)predictor(t,dmodel1);

[yC,or]=predictor(Ah1,dmodel1);

if LearningFunction==1   
   %%%%Uѧϰ����
   UC=abs((0-yC)./sqrt(or));
   if min(UC)>2
       break
   end
   [a,b]=find(UC==min(UC));

   elseif LearningFunction==2    
   %%%%%EFFѧϰ����
   epsEFF=2.*sqrt(or);
   EFF=yC.*(2.*normcdf(-yC./sqrt(or))-normcdf((-epsEFF-yC)./sqrt(or))-normcdf((epsEFF-yC)./sqrt(or)))-sqrt(or).*(2.*normpdf(-yC./sqrt(or))-normpdf((-epsEFF-yC)./sqrt(or))-normpdf((epsEFF-yC)./sqrt(or)))+epsEFF.*(normcdf((epsEFF-yC)./sqrt(or))-normcdf((-epsEFF-yC)./sqrt(or)));
   if max(EFF)<0.001
       break
   end
   [a,b]=find(EFF==max(EFF));

   elseif LearningFunction==3   
   %%%%%������ѧϰ����HH
   HH=abs(log(sqrt(2.*pi).*sqrt(or)+1./2).*(normcdf((2.*sqrt(or)-yC)./sqrt(or))-normcdf((-2.*sqrt(or)-yC)./sqrt(or)))-((2.*sqrt(or)-yC)./2.*normpdf((2.*sqrt(or)-yC)./sqrt(or))+(2.*sqrt(or)+yC)./2.*normpdf((-2.*sqrt(or)-yC)./sqrt(or))));
   if max(HH)<0.3
       break
   end
   [a,b]=find(HH==max(HH));   
   
   elseif LearningFunction==4 
   %%%%%REIFѧϰ����
   EG=sqrt(2./pi).*sqrt(or).*exp(-1./2.*(yC./sqrt(or)).^2)+yC.*(2.*normcdf(yC./sqrt(or))-1);
   REIF=2.*sqrt(or)-EG;
   if max(REIF)<=10^-7
       break
   end
   [a,b]=find(REIF==max(REIF));
   
   elseif LearningFunction==5  
   %%%%%REIF2ѧϰ����
   EG=sqrt(2./pi).*sqrt(or).*exp(-1./2.*(yC./sqrt(or)).^2)+yC.*(2.*normcdf(yC./sqrt(or))-1);
   REIF2=(2.*sqrt(or)-EG).*mvnpdf(Ah1,Mu,cov_matrix);
   if max(REIF2)<=10^-7
       break
   end
   [a,b]=find(REIF2==max(REIF2));
  
   elseif LearningFunction==6
   %%%%%proposed��ѧϰ����
   EG=sqrt(2./pi).*sqrt(or).*exp(-1./2.*(yC./sqrt(or)).^2)+yC.*(2.*normcdf(yC./sqrt(or))-1);
   VG=yC.^2+or-EG.^2;
   %%%x=muf,y=epst
   hj1=@(x,y,mm,ss)y.*(normcdf((x-mm)./ss)-normcdf((-x-mm)./ss))-(sqrt(2./pi).*ss.*exp(-1./2.*(mm./ss).^2)+mm.*(2.*normcdf(mm./ss)-1))+ss.*(normpdf((x-mm)./ss)+normpdf((x+mm)./ss))+mm.*(normcdf((x+mm)./ss)-normcdf((x-mm)./ss));
   hj2=@(x,y,mm,ss)(y-x).*(normcdf((y-mm)./ss)-normcdf((-y-mm)./ss)-normcdf((x-mm)./ss)+normcdf((-x-mm)./ss));
   hj12=@(x,y,mm,ss)hj1(x,y,mm,ss)+hj2(x,y,mm,ss);
   cegma_xishu=2;
   VG_new=cegma_xishu.*sqrt(VG);
   VGEG=VG_new-EG;
   [aa bb]=find(VGEG<=0);
   [cc dd]=find(VGEG>0);
   VG_new1=VG_new(aa,:);
   hj=@(x,mm,ss)x.*(normcdf((x-mm)./ss)-normcdf((-x-mm)./ss))-(sqrt(2./pi).*ss.*exp(-1./2.*(mm./ss).^2)+mm.*(2.*normcdf(mm./ss)-1))+ss.*(normpdf((x-mm)./ss)+normpdf((x+mm)./ss))+mm.*(normcdf((x+mm)./ss)-normcdf((x-mm)./ss));
   h_new=hj(VG_new1,yC(aa,:),sqrt(or(aa,:)));
   EG2=EG(cc,:);
   VG_new2=VG_new(cc,:);
   h_new2=hj12(EG2,VG_new2,yC(cc,:),sqrt(or(cc,:)));
   h_new1=zeros(size(yC,1),1);
   h_new1(aa,:)=h_new;
   h_new1(cc,:)=h_new2;
   if size(cc,1)/N_tianchong<0.005&&size(cc,1)<=50
       break
   end
   [a,b]=find(h_new1==max(h_new1));
   
   elseif LearningFunction==7
   %%%%%LIFѧϰ����
   UC=abs((0-yC)./sqrt(or));
   [a1,b1]=find(UC<=2);
   if length(a1)<1
       break
   end
   UC11=UC;
   Ah11=Ah1;
   yC11=yC;
   or11=or;  
   JF=mvnpdf(Ah11,Mu,cov_matrix);
   if mod(n,2)==0
       LIF=normcdf(-UC11).*JF.*(yC11.^n+or11);%%%%%%%%%%%%ֻ���2ά����
   else
       LIF=zeros(size(yC11,1),1); 
       for i=0:n
           lif_f=@(t)t.^i.*exp(-t.^2./2);
           for j=1:size(yC11,1)
               lif_jf(j,1)=quadgk(lif_f,-yC11(j,1)./sqrt(or11(j,1)),+inf);
           end
           LIF=LIF+normcdf(-UC11).*JF.*sqrt(2./pi).*nchoosek(n,i).*yC11.^(n-i).*sqrt(or11).^i.*lif_jf; 
           clear lif_jf
       end
   end
   Samnum=100;
   Subsam=N./Samnum;
for j=1:Samnum
    [yC22,or22]=predictor(Ah(((j-1)*Subsam+1):(j*Subsam),:),dmodel1);
    GKA1(:,j)=yC22;
    OR22(:,j)=or22;
    UC22(:,j)=abs((0-yC22)./sqrt(or22));
end
   GKA=GKA1(:);
   ORA=OR22(:);
   UC33=UC22(:);
   [aa bb]=find(GKA<=0);
   PF_LIF(h)=length(aa)./length(GKA);
   if PF_LIF(h)==0
       PF_LIF(h)=10.^-5;
   end
   UF(h)=mean(normcdf(-UC33));
   lif_wc(h)=UF(h)/PF_LIF(h);
   if lif_wc(h)<=0.01
       break
   end
   [a,b]=find(LIF==max(LIF));

end

CCC=Ah1(a,:);
Ah1(a,:)=[];
GCe=G(CCC);   
Data=[Data;CCC];
g0=[g0;GCe];
h
end
    Samnum=100;
    Subsam=N./Samnum;
for j=1:Samnum
    GKA1(:,j)=GK(Ah(((j-1)*Subsam+1):(j*Subsam),:));
    j
end
    GKA=GKA1(:);
    [aa bb]=find(GKA<=0);
    PF=length(aa)./length(GKA)
    DET_PF=sqrt((1-PF)./((N-1).*PF))
    Ncall=N0+h-1


