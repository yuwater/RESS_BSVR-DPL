function f=Randomcdf(distribution, mu, sigma,x)
% generate random variables

if strcmp(distribution, 'normal')
    f = normcdf(x,mu,sigma);
    elseif strcmp(distribution, 'uniform')
       f=unifcdf(x,mu,sigma); 
   elseif strcmp(distribution, 'lognormal')
        sln=sqrt(log(1+(sigma/mu)^2));
        mln=log(mu)-sln^2/2;
        f=logncdf(x,mln,sln);
   elseif strcmp(distribution, 'gumbel')        
        aev=sqrt(6)*sigma/pi;
        uev=-psi(1)*aev-mu;
        f=evcdf(-x,uev,aev);  
   elseif strcmp(distribution,'Weibull') 
        f=wblcdf(x,mu,sigma);

end