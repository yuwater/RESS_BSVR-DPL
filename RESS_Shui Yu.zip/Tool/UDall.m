
function UDpoints = UDall(n,s)
% 均匀分布表  好格子点法 
% n  水平数    s  因素数
h = 1:n;
ind = gcd(h,n)==1;  %寻找比n小且与n互素的数h
hm = h(ind);              %生成向量    
m = length(hm);           %生成向量维数，不小于因素数 s
udt = mod(h'*hm,n);       %好格子点法
ind0 = udt==0; 
udt(ind0)=n;              %生成均匀设计表U(n^s)
%udt(end,:)=[];           %生成均匀设计表U^*((n-1)^s)
if s>m
    disp('s必须小于或等于m');
    return;
else
    mcs =nchoosek(m,s);
    if mcs<1e5
        tind = nchoosek(1:m,s);
        [p,~] = size(tind);cd2 = zeros(p,1);
        for k=1:p
            UT = udt(1:n,tind(k,:));
            cd2(k,1) = UDCD2(UT);
        end
            tc=tind(abs(cd2 - min(cd2))<1e-5,:);
            for r=1:size(tc,1)
                uns (:,:,r)= udt(:,tc(r,:));
            end
    else
        for k = 1:n
            a = k;
            UT = mod(h'*a.^(0:s-1),n);
            cd2(k,1) = UDCD2(UT);
        end
        tc = find(abs(cd2 - min(cd2))<1e-5);
        for r=1:size(tc,1)
            uns (:,:,r)=  mod(h'*tc(r).^(0:s-1),n);
        end
        ind0 = uns==0; uns(ind0)=n;
    end  
end
% ud1=linspace(low,upp,n);
[ UDpoints]=uns (:,:,1);
% for i=1:s
%     UDcol1=UD1(:,i);
%     for j=1:n
%           UDcol1(UDcol1==j)=ud1(j);
%     end
%     UDpoints(:,i)=UDcol1;
% end
end

function CD2 = UDCD2(UT)
%中心化L2偏差 CD2
U = UT;
[n,s] = size(U);
X = (2*U-1)/(2*n);
cs1 = zeros(n,1);
for k=1:n
    CSP=1;
    for i=1:s
        CSP = CSP*(2+abs(X(k,i)-1/2)-(X(k,i)-1/2)^2);
    end
    cs1(k) = CSP;
end
CS1=sum(cs1);
cs2 = zeros(n,n);
for k=1:n    
    for l=1:n
        CSP=1;
        for i=1:s
            CSP = CSP*(1+1/2*abs(X(k,i)-1/2)+1/2*abs(X(l,i)-1/2)-1/2*abs(X(k,i)-X(l,i)));
        end
        cs2(k,l) = CSP;
    end
end
CS2 = sum(sum(cs2));
CS = (13/12)^s - 2^(1-s)/n*CS1 + 1/(n^2)*CS2;
CD2 = sqrt(CS);
end
