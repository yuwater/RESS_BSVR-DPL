format long
clear all

problem.performanceFunc = @cantilever_beam;

problem.variable_table = {
    % distribution      mean                   std    
   'gumbel',                1.8e4,             4e3;           %F1
   'gumbel',                3e4,               3e3;           %F2
   'gumbel',                3e4,               1e3;           %F3
   'gumbel',                3e4,               1e3;           %F4
   'lognormal',             2.5,               0.001;         % 
   'lognormal',             2.5,               0.001;         % 
   'lognormal',             2.5,               0.001;         %
   'lognormal',             2.5,               0.001;         %
   'normal',                2e4,               1e3;           % 
   'normal',                1e3,               10;            %
   'normal',               3e4,               6e3;           %
   'normal',               2e4,               2e3;           %
   'normal',               0.25,               5e-4;          %
   'normal',               1.75,               0.001;         %
   'normal',               1.25,               0.001;         %
   'normal',               4.75,               0.001;         %
   'normal',               5e4,               5e3;           %
   'normal',               3e4,               3e3;           %
   'normal',                0.2,               1e-4;          %
   'normal',                0.4,               1e-4;          %
   'normal',               1.2e8,             1.2e7;         %
    };
solve(problem);

function solve(problem)


MCS_par.n_MCS = 2e6;
result.MCS = MCS(problem, MCS_par);

option.Nt=3e3;
option.Ns=1e6;
result. AF= AF(problem,option);

option.Nt=3e3;
option.Ns=1e6;
result.AK_EFF= AK_EFF(problem, option);

option.Nt=3e3;
option.Ns=1e6;
result.AK_HH= AK_HH(problem, option);

option.Nt=3e3;
option.Ns=1e6;
result.AK_U= AK_U(problem, option);

save('result.mat', 'result');


load result
x1 = 1:1:result.AF.Ncall;
x2 = 1:1:result.AK_EFF.Ncall;
x3 = 1:1:result.AK_HH.Ncall;
x4 = 1:1:result.AK_U.Ncall;
x5 = 1:1:100;
y1 = result.AF.pf;
y2 = result.AK_EFF.pf;
y3 = result.AK_HH.pf;
y4 = result.AK_U.pf;
y5 = repmat(result.MCS.pf,100,1);
plot(x1,y1,'r-s',x2,y2,'b-d',x3,y3,'m-v',x4,y4,'g-p',x5,y5,'k-','LineWidth',1,'markersize',3);
legend('AF','AK EFF','AK HH','AK U','MCS');
title('example1','Fontsize',10,'Fontname','Times New Roman');
xlabel('Ncall','FontName','Times New Roman','FontSize',10);
ylabel('pf','FontName','Times New Roman','FontSize',10);
axis([0,40,0,0.2])
end