


format long
clear all


problem.performanceFunc = @Truss1;

problem.variable_table = {
    % distribution      mean            std  
   'lognormal',            2e-3,            2e-4;              %A1
   'lognormal',            2e-3,            2e-4;              %A2
   'lognormal',            2.1e11,         2.1e10;          %E1
   'lognormal',            2.1e11,         2.1e10;          %E2
   'gumbel',                5e4,               7.5e3;           %P1
   'gumbel',                5e4,               7.5e3;           %P2
   'gumbel',                5e4,               7.5e3;           %P3
   'gumbel',                5e4,               7.5e3;           %P4
   'gumbel',                5e4,               7.5e3;           %P5
   'gumbel',                5e4,               7.5e3;           %P6
    };
solve(problem);

function solve(problem)

%{
MCS_par.n_MCS = 2e6;
result.MCS = MCS(problem, MCS_par);



option.Nt=1e4;
option.Ns=1e6;
result.AK_EFF= AK_EFF(problem, option);
%}
option.Nt=1e4;
option.Ns=1e6;
result.AF= AF(problem,option);

option.Nt=1e4;
option.Ns=1e6;
result.AK_HH= AK_HH(problem, option);

option.Nt=1e4;
option.Ns=1e6;
result.AK_U= AK_U(problem, option);

save('result.mat', 'result');



load result
x1 = 1:1:result.AF.Ncall;
x2 = 1:1:result.AK_EFF.Ncall;
x3 = 1:1:result.AK_HH.Ncall;
x4 = 1:1:result.AK_U.Ncall;
x5 = 1:1:100;
y1 = result.AF.pf;
y2 = result.AK_EFF.pf;
y3 = result.AK_HH.pf;
y4 = result.AK_U.pf;
y5 = repmat(result.MCS.pf,100,1);
plot(x1,y1,'r-s',x2,y2,'b-d',x3,y3,'m-v',x4,y4,'g-p',x5,y5,'k-','LineWidth',1,'markersize',3);
legend('AF','AK EFF','AK HH','AK U','MCS');
title('example1','Fontsize',10,'Fontname','Times New Roman');
xlabel('Ncall','FontName','Times New Roman','FontSize',10);
ylabel('pf','FontName','Times New Roman','FontSize',10);
axis([0,40,0,0.2])

end
