


function g = Truss1(x)

   A1 = x(1);        A2 =  x(2);
   E1 = x(3);        E2 = x(4);
   F1 = x(5);        F2 = x(6);        F3 = x(7);        F4 = x(8);        F5 =  x(9);        F6 = x(10);
%  addpath('FEM');       
E_vec=[E1*ones(1,11), E2*ones(1,12)];
A_vec=[A1*ones(1,11), A2*ones(1,12)];

% generation of coordinates and connectivities
nodesCoords=[0 0; 2 2; 4 0; 6 2; 8 0; 10 2; 12 0; 14 2; 16 0; 18 2; 20 0; 22 2; 24 0];
numberNodes=size(nodesCoords,1);

elementNodes=[ 1 3; 3 5; 5 7; 7 9;    9 11; 11 13;...
                           2 4; 4 6; 6 8; 8 10; 10 12;...
                           1 2; 2 3; 3 4; 4 5;    5 6;    6 7; 7 8; 8 9; 9 10; 10 11; 11 12; 12 13];
numberElements=size(elementNodes,1);

% GDof: total number of degrees of freedom
GDof=2*numberNodes;

% Assembly stiffness matrix
K_assembly=formStiffness2Dtruss(GDof,numberElements,elementNodes,nodesCoords,E_vec,A_vec);

% boundary conditions
prescribedDof=[1 2 26];

% force : force vector
F_col=nan(GDof,1);
F_col(4)=-F1;
F_col(8)=-F2;
F_col(12)=-F3;
F_col(16)=-F4;
F_col(20)=-F5;
F_col(24)=-F6;
F_col([3,5,6,7,9,10,11,13,14,15,17,18,19,21,22,23,25,26])=0;

%displacement vector
D_col=nan(GDof,1);
D_col(prescribedDof)=0;

% solution
[D_col]=solution(prescribedDof,K_assembly,D_col,F_col);
displacement =sqrt(D_col(13)^2+D_col(14)^2);
g=0.12-displacement;



end
