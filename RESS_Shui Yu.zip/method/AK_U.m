function result= AK_U(problem, option)
variable_table = problem.variable_table;
performanceFunc = problem.performanceFunc;
dim= size(variable_table,1);
N0=2*dim;
N_tianchong=option.Nt;
N_sim=option.Ns;

Mu=zeros(1,dim);
Sigma=ones(1,dim);

for i=1:dim
    Data(:,i)=unifrnd(Mu(i)-5.*Sigma(i),Mu(i)+5.*Sigma(i),N0,1);
    Data_tiankong(:,i)=unifrnd(Mu(i)-5.*Sigma(i),Mu(i)+5.*Sigma(i),N_tianchong,1);
end
xi= NatafTransformation(Data, variable_table, -1 );
x_un= NatafTransformation(Data_tiankong, variable_table, -1 );


for i=1:N0
     Eva(i)=performanceFunc(xi(i,:));
end
for h=1:1000
        theta=10*ones(1,dim); lob=1e-2*ones(1,dim); upb=20*ones(1,dim);
        [dmodel, ~]=dacefit(xi,Eva,@regpoly1,@corrgauss,theta,lob,upb);
        GK=@(t)predictor(t,dmodel);

        [yC,or]=predictor(x_un,dmodel);
        UC=abs((0-yC)./sqrt(or));
%{
if h>1 
 Samnum=100;
    Subsam=N_sim./Samnum;
    for   rv_id = 1:dim
       X_mc(:,rv_id) = ...
              GenerateRV( ...
                                   variable_table{rv_id,1}, ...
                                   variable_table{rv_id,2}, ...
                                   variable_table{rv_id,3}, ...
                                   N_sim);
   end
for j=1:Samnum
    GKA1(:,j)=GK(X_mc(((j-1)*Subsam+1):(j*Subsam),:));
end

    GKA=GKA1(:);
    [aa bb]=find(GKA<=0);
    Pf(h-1,:)=length(aa)./length(GKA);

end
%}
min_V(h,:) = min(or);        
   if min(UC)>2
       break
   end
   
   [a,b]=find(UC==min(UC));
   CCC=x_un(a,:);
  x_un(a,:)=[];
  GCe=performanceFunc(CCC);   
  xi=[xi;CCC];
  Eva=[Eva,GCe];
end
    Samnum=100;
    Subsam=N_sim./Samnum;
    for   rv_id = 1:dim
       X_mcs(:,rv_id) = ...
              GenerateRV( ...
                                   variable_table{rv_id,1}, ...
                                   variable_table{rv_id,2}, ...
                                   variable_table{rv_id,3}, ...
                                   N_sim);
   end
for j=1:Samnum
    GKA1(:,j)=GK(X_mcs(((j-1)*Subsam+1):(j*Subsam),:));
end
    GKA=GKA1(:);
    [aa bb]=find(GKA<=0);
    PF=length(aa)./length(GKA);
    COV=sqrt((1-PF)./((N_sim-1).*PF));
    Ncall=h-1;
    
    fprintf('%16s%32s%32s\n','Pf_AKU', 'Ncall ','COV')
   fprintf('%16d%30f%32f\n', PF, Ncall, COV);
    disp('----------------------------------------------------------------------------------------------------------------')
result.Pf=PF;
result.COV=COV;
result.Ncall=Ncall;
%result.pf = Pf;

end

