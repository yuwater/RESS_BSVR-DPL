
function result = AF( problem, option )
variable_table = problem.variable_table;
g = problem.performanceFunc;
d= size(variable_table,1);
n1=option.Nt;
N_sim=option.Ns;
n = 3*d;

for i=1:d
x(:,i)=unifrnd(-3,3,n,1);
x1(:,i) = unifrnd(-3,3,n1,1);
end


X= NatafTransformation(x, variable_table, -1 );
X1= NatafTransformation(x1, variable_table, -1 );

for i = 1:n
Y(i,:)=g(X(i,:));
end
for i = 1:n1
Y1(i,:)=g(X1(i,:));
end     %输出响应值  

Input=X; Output=Y;%训练样本点

ID = [];

length_ID = 0;

for i = 1:1000

Hyperparameters=([100  1.*ones(1,d)]);               %Initial values of Hyper-parameters
lb=([1     0.0001.*ones(1,d)]);                      %lower bound of Hyper-parameters
ub=([10^7  1000.*ones(1,d)]);                        %upper bound of Hyper-parameters 
model= SVRmodel(Input,Output,Hyperparameters,lb,ub); %Training a Beyesian least square SVR model
GK =@(t)SVRPredict(t,model);
[PY,V]=SVRPredict(X1,model);                         %Making prediction
max_V=sqrt(max(V));
%{
if i>1 
 Samnum=100;
    Subsam=N_sim./Samnum;
    for   rv_id = 1:d
       X_mc(:,rv_id) = ...
              GenerateRV( ...
                                   variable_table{rv_id,1}, ...
                                   variable_table{rv_id,2}, ...
                                   variable_table{rv_id,3}, ...
                                   N_sim);
   end
for j=1:Samnum
    GKA1(:,j)=GK(X_mc(((j-1)*Subsam+1):(j*Subsam),:));
end
    GKA=GKA1(:);
    [aa bb]=find(GKA<=0);
    Pf(i-1,:)=length(aa)./length(GKA);
end
%}
if i == 1 
    delta_1 = mean(sqrt(V),1);
end

% E=[];
D=[];



epsilon = -0.5.*mean(sqrt(V),1)./delta_1.*exp(-1/d);
epsilon_load(i,:) =epsilon;
ID = find(PY./sqrt(V) < epsilon);
NNN = X1(ID,:);

X1(ID,:) = [];
PY(ID,:) = [];
V(ID,:)  = [];
length(ID);%划分安全域
num = length(ID);
ID_NUM(i,:)  = num;
length_ID = length_ID+length(ID);

H = n1-i+1-length_ID;

 for j =1:H
    for k =1:n+i-1
        
        E(k,:)= norm(X1(j,:)-Input(k,:));
    end
    min_E =min(E);
    D=[D;min_E];
end
max_dmin=max(D);
min_dmin=min(D);
U = abs(PY)./sqrt(V);
s = n1-i+1-length_ID;
MIN_PY(i,:)=min(abs(PY));
MIN_V(i,:)=min(V);
min_U(i,:)=min(U);
Af = U.*(max_dmin-min_dmin)./(D-min_dmin.*ones(s,1)+1e-5.*ones(s,1));% learning function
Min_Af =min(Af);
[a,b] =find(Af==min(Af));
NEW_NS =X1(a,:);
X1(a,:) =[];
NEW_G =g(NEW_NS);
Input=[Input;NEW_NS];%新添加样本点
Output=[Output;NEW_G];


if (i>=2)
    if and(min(U)>=2,  ((length(X1)-(n1-length_ID-i+1))/(n1-length_ID-i+1))<0.005);    break, end
end
end
 Samnum=100;
    Subsam=N_sim./Samnum;
    for   rv_id = 1:d
       X_mc(:,rv_id) = ...
              GenerateRV( ...
                                   variable_table{rv_id,1}, ...
                                   variable_table{rv_id,2}, ...
                                   variable_table{rv_id,3}, ...
                                   N_sim);
   end
for j=1:Samnum
    GKA1(:,j)=GK(X_mc(((j-1)*Subsam+1):(j*Subsam),:));
end
    GKA=GKA1(:);
    [aa bb]=find(GKA<=0);
    PF=length(aa)./length(GKA);
    COV=sqrt((1-PF)./((N_sim-1).*PF));;
    Ncall=i-1;
    fprintf('%16s%32s%32s\n','Pf_SVR', 'Ncall ','COV')
    fprintf('%16d%30f%32f\n', PF, Ncall, COV);
    disp('----------------------------------------------------------------------------------------------------------------')
%{
scatter(Input(:,1),Input(:,2),'filled','o','r');
hold on
scatter(X(:,1),X(:,2),'filled','o','b');
hold on
lgd = legend('Test Points','Initial Points');
lgd.FontSize = 12;
lgd.FontWeight = 'bold';

 x1 = linspace( -2, 6, 100 );
 x2 = linspace( -1, 6, 100 );
 [X1,X2]= meshgrid(x1,x2);
 g = sin(2.5*X1)-(X1.^2+4).*(X2-1)/20+2;
gridx = makeEvalGrid( {x1 x2} );
 gk=SVRPredict(gridx,model);
% g = Func( gridx );
 
 contour( X1, X2, g,[0,0]);
 hold on
 contour( x1, x2, reshape( gk, 100, 100),[0 0],'color','r','LineStyle','--');
 clabel(' model','fontsize',8,' limit-state','fontsize',8,LineStyle','--','red');


%}  
 %{ 
   [hAxes,hBar,hLine]=plotyy(0:Ncall,ID_NUM,0:Ncall,epsilon_load,'bar','plot')
title('example1','Fontsize',10,'Fontname','Times New Roman');
xlabel('Ncall','FontName','Times New Roman','FontSize',10);
ylabel('pf','FontName','Times New Roman','FontSize',10);
ylabel(hAxes(1),'the number of cut','FontName','Times New Roman','FontSize',10);
ylabel(hAxes(2),'pf','FontName','Times New Roman','FontSize',10);
%}

result.Pf = PF;
result.COV = COV;
result.Ncall = Ncall;
%result.pf = Pf;
%plot(0:Ncall,epsilon_load,'b')
end