    function result = MCS( problem, option )

% parameter settings
n_MCS=option.n_MCS;
variable_table = problem.variable_table;
performanceFunc = problem.performanceFunc;


nx= size(variable_table,1);
for   rv_id = 1:nx
            X_mcs(:,rv_id) = ...
                GenerateRV( ...
                variable_table{rv_id,1}, ...
                variable_table{rv_id,2}, ...
                variable_table{rv_id,3}, ...
                n_MCS);
end

n_Pf=0;
for i=1:n_MCS
      G = performanceFunc(X_mcs(i,:));
      n_Pf=n_Pf+(G<=0);
      Pf=n_Pf/n_MCS;
end
COV=sqrt((1-Pf)/(n_MCS*Pf));
result.pf =Pf;
result.COV=COV;
result.Ncall=n_MCS;

fprintf('%16s%32s%32s\n', 'Pf', 'Ncall ','Cov')
fprintf('%16d%24f%24f\n', Pf, n_MCS, COV);
 disp('----------------------------------------------------------------------------------------------------------------')
end



