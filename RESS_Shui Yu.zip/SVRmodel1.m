function model= SVRmodel1(X,Y,Hyperparameters,lb,ub)   
%Optimizate the hyperparameters
 Hyperparameters=log(Hyperparameters);  lb=log(lb);   ub=log(ub);
%----------------------Fmincon
 options=optimoptions('fmincon','Display','off'); 
 [Ohp,Of]=fmincon(@SVRLikelihood1,Hyperparameters,[],[],[],[],lb,ub,[],options);
 model=SVRTrain1(X,Y,Ohp);
%-------------------------GA
%  [Ohp,Of]=ga(@SVRLikelihood1,size(Hyperparameters,2),[],[],[],[],lb,ub);
%  model=SVRTrain1(X,Y,Ohp);
%-------------------------
  function Loglikelihood=SVRLikelihood1(Hyperparameters) 
  %Likelihood function
  model= SVRTrain1(X,Y,Hyperparameters);
  HP=exp(Hyperparameters); 
  n=size(X,1);
  Kernel=model.Kernelmatrix;
  parameter=model.parameter;
  Fmp=Kernel*parameter;
  Delta=model.Output-Fmp;
  
  C=HP(1);
  epsilon=model.epsilon;
  theta=HP(3:end);
  
  num=find(abs(Delta)>epsilon);
  Loss=0.5*(abs(Delta(num))-epsilon).^2;
  
  SV=model.SV;  numsv=size(SV,1);
  
  K=Kernel(SV,SV);
  
  Zd=0.5*(numsv*log(C)+log(det(K)));
   
  Loglikelihood=(0.5.*parameter'*Kernel*parameter+C*sum(Loss)+n*(log((2.*pi./C).^0.5+2.*epsilon))+Zd);
   
end 
end 
     
     
     
     
     
     
     