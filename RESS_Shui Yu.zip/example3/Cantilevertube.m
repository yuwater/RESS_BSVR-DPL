function g = Cantilevertube(x)
t = x(:,1);
d = x(:,2);
L1 = x(:,3);
L2 = x(:,4);
F1 = x(:,5);
F2 = x(:,6);
P = x(:,7);
T = x(:,8);
delta = x(:,9);
A = pi./4.*(d.^2-(d-2.*t).^2);
M = F1.*L1.*cos(pi/36)+F2.*L2.*cos(pi/18);
I = pi./64.*(d.^4-(d-2*t).^4);
delta_x = (P+F1.*sin(pi/36)+F2.*sin(pi/18))./A+M.*d./2./I;
tx = T.*d./4./I;
delta_max = sqrt(delta_x.^2+3.*tx.^2);
g = delta-delta_max;


