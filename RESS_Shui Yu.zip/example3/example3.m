format long
clear all

problem.performanceFunc = @Cantilevertube;
problem.variable_table = {
    % distribution      mean        std         
    'normal',                5,       0.1;% t
    'normal',                42,       0.5;% d
    'uniform',               119.75,   120.25;%L1
    'uniform',               59.75,    60.25;%L2
    'normal',                3000,       300;%F1
    'normal',                3000,       300;%F2
    'gumbel',                27000,      2700;%P
    'normal',                90000,       9000;%T
    'normal',                220,       22;%delta
    };  
solve(problem);


function solve(problem)
%{
MCS_par.n_MCS = 2e6;
result.MCS = MCS(problem, MCS_par);

% % %  AK-U
option.Nt=1e4;
option.Ns=1e6;
result.AK_EFF= AK_EFF(problem, option);
%}
option.Nt=1e5;
option.Ns=1e6;
result.AF= AF(problem,option);

option.Nt=1e4;
option.Ns=1e6;
result.AK_HH= AK_HH(problem, option);

option.Nt=1e4;
option.Ns=1e6;
result.AK_U= AK_U(problem, option);
save('result.mat', 'result');

 
load result
x1 = 1:1:result.AF.Ncall;
x2 = 1:1:result.AK_EFF.Ncall;
x3 = 1:1:result.AK_HH.Ncall;
x4 = 1:1:result.AK_U.Ncall;
x5 = 1:1:100;
y1 = result.AF.pf;
y2 = result.AK_EFF.pf;
y3 = result.AK_HH.pf;
y4 = result.AK_U.pf;
y5 = repmat(result.MCS.pf,100,1);
plot(x1,y1,'r-s',x2,y2,'b-d',x3,y3,'m-v',x4,y4,'g-p',x5,y5,'k-','LineWidth',1,'markersize',3);
legend('AF','AK EFF','AK HH','AK U','MCS');
title('example1','Fontsize',10,'Fontname','Times New Roman');
xlabel('Ncall','FontName','Times New Roman','FontSize',10);
ylabel('pf','FontName','Times New Roman','FontSize',10);
axis([0,40,0,0.2])
end
