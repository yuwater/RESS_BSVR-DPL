clc
clear all
addpath('example1','example2','example3','example4','example5','method','Kriging');     
addpath('Tool');addpath('Tool/FEM');
