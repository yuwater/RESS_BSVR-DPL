# dace-toolbox-source

DACE (Design and Analysis of Computer Experiments) is a kriging toolbox for Matlab. Full details at the DACE website [here](http://www2.imm.dtu.dk/projects/dace/).

DACE was written by Hans Bruun Nielsen (hbn@imm.dtu.dk), Søren Nymand and Lophaven Jacob Søndergaard.
